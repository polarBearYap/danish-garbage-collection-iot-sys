"""
Author: Yap Jheng Khin
Sample code: AWS Official Documentation
"""
# Import third-party libraries
from dlr import DLRModel
from json import dumps
import numpy as np
from numpy import argsort
from scipy.special import softmax
from sys import modules

# Import local files/modules
import config_utils

config_utils.logger.info("Using dlr from '{}'.".format(modules[DLRModel.__module__].__file__))
config_utils.logger.info("Using np from '{}'.".format(modules[argsort.__module__].__file__))
config_utils.logger.info("Using scipy from '{}'.".format(modules[softmax.__module__].__file__))

# Load the trash classifier
dlr_model = DLRModel(
    config_utils.comp_config.model_dir, 
    config_utils.comp_config.accelerator
)

# Model labels
TRASH_DICT = {
    '1': 'glass',
    '2': 'metal',
    '3': 'paper',
    '4': 'plastic',
    '5': 'metal',
    '6': 'trash'
}

def crop_center(
    img, 
    cropx = config_utils.comp_config.image_shape[0], 
    cropy = config_utils.comp_config.image_shape[1]
):
    """
    Crop the image to the center.
    
    Original Author: Divakar
    Source code: https://stackoverflow.com/a/39382475
    """
    y, x, _ = img.shape
    startx = x // 2-(cropx // 2)
    starty = y // 2-(cropy // 2)    
    return img[starty:starty+cropy, startx:startx+cropx, :]

def classify_trash(
    inference_request, 
    image,
    max_no_predictions = config_utils.comp_config.max_no_of_results, 
    score_threshold = config_utils.comp_config.score_threshold
):
    """
    Performs image classification and predicts using the model.

    Author: Yap Jheng Khin
    """

    # Define the inference log    
    inference_log = {}
    inference_log["client-id"] = inference_request["client-id"]
    inference_log["utc-timestamp"] = inference_request["utc-timestamp"]
    inference_log["img-format"] = inference_request["action"]["img-format"]
    inference_log["inference-type"] = inference_request["action"]["type"]
    inference_log["inference-description"] = "Top {} predictions with score {} or above ".format(
        max_no_predictions, score_threshold
    )
    inference_log["inference-results"] = []

    pred_trash_type = None

    try:        
        # ------------------------------------------------ #
        # Preprocess image
        # ------------------------------------------------ #
        # Note that the data preprocessor is not robust to handle data that is outside of the dataset
        # Only center cropping is applied
        # It means that the data preprocessor cannot handle too large or too small images
        MEAN = np.array([0.485, 0.456, 0.406])[:, np.newaxis, np.newaxis]
        STD = np.array([0.229, 0.224, 0.225])[:, np.newaxis, np.newaxis]

        # Crop the image to the center
        image = crop_center(np.array(image))
        # Convert hwc to chw
        image = np.moveaxis(image, -1, 0)
        # Normalize image
        image = ((image / 255) - MEAN) / STD
        # Convert chw to nchw
        image = image[np.newaxis, :]

        # ------------------------------------------------ #
        # Perform inference
        # ------------------------------------------------ #
        # Run DLR to perform inference with DLC optimized model
        model_output = dlr_model.run(image)
        # Compute the class probabilities
        probabilities = softmax(model_output[0][0])
        # Sort the probabilities in descending order
        sort_classes_by_probability = np.argsort(probabilities)[::-1]
        # Append results to PAYLOAD
        for i in sort_classes_by_probability[: max_no_predictions]:
            if probabilities[i] >= score_threshold:
                result = {"Label": str(TRASH_DICT[str(i+1)]), "Confidence": str(probabilities[i])}
                inference_log["inference-results"].append(result)

        # Retrieve the prediction and confidence score
        pred_trash_idx = sort_classes_by_probability[0]
        pred_trash_type = TRASH_DICT[str(pred_trash_idx+1)]

        config_utils.logger.info(f'Successfully performed the inference for request client-id={inference_request["client-id"]}, utc-timestamp={inference_request["utc-timestamp"]}.')
        config_utils.logger.info(dumps(inference_log))
    except Exception as e:
        config_utils.logger.error("Exception occurred during prediction: {}".format(e))
    finally:
        return pred_trash_type, inference_log