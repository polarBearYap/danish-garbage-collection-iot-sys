"""
Author: Yap Jheng Khin
Sample code: AWS Official Documentation
"""
# Import third-party libraries
from awscrt.io import (
    ClientBootstrap,
    DefaultHostResolver,
    EventLoopGroup,
    SocketDomain,
    SocketOptions
)
from awsiot.eventstreamrpc import (
    Connection, 
    LifecycleHandler, 
    MessageAmendment
)
import awsiot.greengrasscoreipc.client
from awsiot.greengrasscoreipc.model import (
    BinaryMessage,
    GetConfigurationRequest,
    PublishMessage,
    PublishToTopicRequest,
    # QOS,
    SubscribeToConfigurationUpdateRequest,
    SubscribeToTopicRequest,
    UnauthorizedError
)
import concurrent.futures
import json
import os

# Import local files/modules
import config_utils
import stream_handlers

class IPCClient:
    def __init__(self, connection_timeout):
        self.connection_timeout = connection_timeout

        # Get the ipc client
        try:    
            self.ipc_client = awsiot.greengrasscoreipc.connect()
            config_utils.logger.info("Created IPC client")
        except Exception as e:
            config_utils.logger.error(
                "Exception occurred during the creation of an IPC client: {}".format(e)
            )
            exit(1)

    def connect(self, timeout=None):
        """
        Author: Amazon
        """
        if timeout == None:
            timeout = self.connection_timeout

        elg = EventLoopGroup()
        resolver = DefaultHostResolver(elg)
        bootstrap = ClientBootstrap(elg, resolver)
        socket_options = SocketOptions()
        socket_options.domain = SocketDomain.Local
        amender = MessageAmendment.create_static_authtoken_amender(os.getenv("SVCUID"))
        hostname = os.getenv("AWS_GG_NUCLEUS_DOMAIN_SOCKET_FILEPATH_FOR_COMPONENT")
        connection = Connection(
            host_name=hostname,
            port=8033,
            bootstrap=bootstrap,
            socket_options=socket_options,
            connect_message_amender=amender,
        )
        self.lifecycle_handler = LifecycleHandler()
        connect_future = connection.connect(self.lifecycle_handler)
        connect_future.result(timeout)
        return connection

    def subscribe_topic(self, topic_to_subscribe, subscription_handler, timeout=None):
        """
        Author: Yap Jheng Khin

        Ipc client creates a request and activates the operation to subscribe a topic.
        """
        if timeout == None:
            timeout = self.connection_timeout

        # Send a subscription request to the IPC service and expect a stream of event messages in response. 
        operation = self.ipc_client.new_subscribe_to_topic(subscription_handler)
        # Activate the operation to start receiving images from the subscribed topic
        request = SubscribeToTopicRequest()
        request.topic = topic_to_subscribe
        future = operation.activate(request)

        try:
            future.result(timeout)
            config_utils.logger.info(f"Successfully subscribed to {topic_to_subscribe}")
        except concurrent.futures.TimeoutError as e:
            config_utils.logger.error(f"Timeout occurred while subscribing to {topic_to_subscribe}: {e}")
            raise e
        except UnauthorizedError as e:
            config_utils.logger.error(f"Unauthorized error while subscribing to {topic_to_subscribe}: '{e}")
            raise e
        except Exception as e:
            config_utils.logger.error(f"Exception while subscribing to {topic_to_subscribe}: {e}")
            raise e

    def publish_json_to_topic(self, topic_to_publish, json_payload, timeout=None):
        """
        Author: Yap Jheng Khin

        Ipc client creates a request and activates the operation to publish JSON data to a topic.
        """
        if timeout == None:
            timeout = self.connection_timeout

        try:

            # Create a publish request
            request = PublishToTopicRequest()
            request.topic = topic_to_publish
            publish_message = PublishMessage()
            publish_message.binary_message = BinaryMessage()
            payload = json.dumps(json_payload).encode('utf-8')
            publish_message.binary_message.message = payload
            request.publish_message = publish_message

            # Send the publish request to the IPC service
            operation = self.ipc_client.new_publish_to_topic()
            # Activate the operation to start publishing model predictions to the topic
            operation.activate(request)
            futureResponse = operation.get_response()

            futureResponse.result(timeout)
            config_utils.logger.info(f'Successfully published to {topic_to_publish}: {payload}')
        except concurrent.futures.TimeoutError as e:
            config_utils.logger.error(f"Timeout occurred while publishing to {topic_to_publish}: {e}")
            raise e
        except UnauthorizedError as e:
            config_utils.logger.error(f"Unauthorized error while publishing to {topic_to_publish}: '{e}")
            raise e
        except Exception as e:
            config_utils.logger.error(f"Exception while publishing to {topic_to_publish}: {e}")
            raise e

    def get_configuration(self, timeout=None):
        """
        Author: Amazon

        Ipc client creates a request and activates the operation to get the configuration of
        inference component passed in its recipe.

        :return: A dictionary object of DefaultConfiguration from the recipe.
        """
        if timeout == None:
            timeout = self.connection_timeout

        try:
            request = GetConfigurationRequest()
            operation = self.ipc_client.new_get_configuration()
            operation.activate(request).result(timeout)
            result = operation.get_response().result(timeout)
            return_result = result.value
            config_utils.logger.info("Successfully retrieved the inference component's configuration")
            return return_result
        except Exception as e:
            config_utils.logger.error(
                "Exception occurred during fetching the configuration: {}".format(e)
            )
            exit(1)

    def get_config_updates(self, timeout=None):
        """
        Author: Amazon

        Ipc client creates a request and activates the operation to subscribe to the configuration changes.
        """
        if timeout == None:
            timeout = self.connection_timeout

        try:
            subsreq = SubscribeToConfigurationUpdateRequest()
            subscribe_operation = self.ipc_client.new_subscribe_to_configuration_update(
                stream_handlers.ConfigUpdateHandler()
            )
            subscribe_operation.activate(subsreq).result(timeout)
            subscribe_operation.get_response().result(timeout)
            config_utils.logger.info("Successfully subscribed to the inference component's configuration changes")
        except Exception as e:
            config_utils.logger.error(
                "Exception occurred during fetching the configuration updates: {}".format(e)
            )
            exit(1)