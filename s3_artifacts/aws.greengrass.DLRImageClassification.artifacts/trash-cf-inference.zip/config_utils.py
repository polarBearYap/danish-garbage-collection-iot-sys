"""
Author: Yap Jheng Khin
Sample code: AWS Official Documentation
"""
# Import third-party libraries
from awsiot.greengrasscoreipc.model import QOS
from collections import deque
from dataclasses import dataclass
from datetime import datetime
from logging import (
    INFO, 
    StreamHandler, 
    getLogger
)
import os
import pathlib
from random import shuffle as shuffle_arr
from sys import stdout

# --------------------------------------------------------------- #
# Struct that stores component configurations for other files/ 
# modules to access
# --------------------------------------------------------------- #
@dataclass
class InferenceComponentConfig:
    accelerator = "cpu"
    image_and_model_output_bucket_name = "danish-gcs-image-and-model-output-bucket" # the bucket that store images and model outputs
    image_shape = (224, 224)
    max_no_of_results = 3
    qos_type = QOS.AT_LEAST_ONCE
    score_threshold = 0.5
    timeout=30 # the default timeout to activate mqtt topic subscription is 30 seconds
    topic_to_subscribe="command/danish-gcs/core/1/trash-classification" # the default topic that the component subscribes to receive input images
    # Get the paths from the env variables.
    model_dir = os.path.expandvars(os.environ.get("TRASH_CF_MODEL_DIR"))
    device_img_dir = os.path.expandvars(os.environ.get("DEVICE_IMAGE_PATH"))
    sample_device_img_dir = os.path.expandvars(os.environ.get("SAMPLE_DEVICE_IMAGE_PATH"))
    model_output_dir = os.path.expandvars(os.environ.get("MODEL_OUTPUT_PATH"))
    image_idx = 0
    sample_images = []
    model_output_filename = f"model-outputs.txt"

# --------------------------------------------------------------- #
# Constants that are shared between files and modules
# --------------------------------------------------------------- #
UPDATED_CONFIG = False
comp_config = InferenceComponentConfig()
inference_requests_queue = deque()

# --------------------------------------------------------------- #
# Get a logger
# --------------------------------------------------------------- #
logger = getLogger()
handler = StreamHandler(stdout)
logger.setLevel(INFO)
logger.addHandler(handler)

# --------------------------------------------------------------- #
# Unit conversion constants
# --------------------------------------------------------------- #
BYTES = {
    "5MiB": 5242880,
    "16MiB": 16777216,
    "256MiB": 268435456
}
MILLISECONDS = {
    "24hr": 9223372036854 
}

# --------------------------------------------------------------- #
# Variables that are configurable from the component's recipe
# The default values can be overwritten by component's recipe
# --------------------------------------------------------------- #

def set_configuration(config):
    """
    Author: Amazon

    Sets a new config object with the combination of updated and default configuration as applicable.
    Calls inference code with the new config and indicates that the configuration changed.
    """
    comp_config = InferenceComponentConfig()

    if "Accelerator" in config:
        comp_config.accelerator = config["Accelerator"]

    if "ConnectionTimeout" in config:
        comp_config.timeout = config["ConnectionTimeout"]

    if "ExpectedInputImage" in config:
        (width, height) = comp_config.image_shape
        if "Width" in config["ExpectedInputImage"]:
            width = config["ExpectedInputImage"]["Width"]
        if "Height" in config["ExpectedInputImage"]:
            height = config["ExpectedInputImage"]["Height"]
        comp_config.image_shape = (width, height)

    if "ReceiveInferenceRequestOnTopic" in config:
        comp_config.topic_to_subscribe = config["ReceiveInferenceRequestOnTopic"]

    if "QOS" in config:
        comp_config.qos_type = config["QOS"]

    if "UploadImageAndModelOutputOnBucket" in config:
        comp_config.image_and_model_output_bucket_name = config["UploadImageAndModelOutputOnBucket"]

    if "ModelOutputOptions" in config:
        if "MaxNumberResultsToKeep" in config["ModelOutputOptions"]:
            comp_config.max_no_of_results = config["ModelOutputOptions"]["MaxNumberResultsToKeep"]
        if "ConfidenceThreshold" in config["ModelOutputOptions"]:
            comp_config.score_threshold = config["ModelOutputOptions"]["ConfidenceThreshold"]

    # ------------------------------------------------------------------------------------------------ #
    # Create directories to store images and model outputs, respectively
    # ------------------------------------------------------------------------------------------------ #
    if not os.path.exists(comp_config.device_img_dir):
        os.makedirs(comp_config.device_img_dir)
    else: # Else if the device image's directory exists
        # Remove any old image zipped files in the `device_img_dir` and its parent directory
        # Note that it didn't delete the existing unzipped images in the `device_img_dir`
        device_img_parent_path = pathlib.Path(comp_config.device_img_dir).parent.absolute()
        paths = [comp_config.device_img_dir, device_img_parent_path]
        for path in paths:
            for file in os.listdir(path):
                if file.endswith('.zip'):
                    os.remove(os.path.join(path, file))

    if not os.path.exists(comp_config.model_output_dir):
        os.makedirs(comp_config.model_output_dir)

    # ------------------------------------------------------------------------------------------------ #
    # Copy images from artifacts to the component's work directory
    # AWS IoT MQTT cannot support heavy payload. The component assumes that the developers use other
    # protocols such as HTTPS to send image to the core device.
    # For this assignment, simple copy and paste operation is used instead for simplicity.
    # ------------------------------------------------------------------------------------------------ #
    try:
        # Since no IoT hardware is available, randomly pick one image from the sample image directory to perform inference
        comp_config.sample_images = os.listdir(comp_config.sample_device_img_dir)
        shuffle_arr(comp_config.sample_images)
    except Exception as e:
        logger.error(f"Error happens when getting images from {comp_config.sample_device_img_dir}: {e}")

    # **IMPORTANT**
    # In production environment, the component should make relevant changes based on the updated configuration.
    # Now, the component will not be updated upon subsequent configuration updates.
    # If configuration changes have been applied, please uninstall and redeploy the component again.
    # Refer to artifacts from public components aws.greengrass.DLRImageClassification to learn on how to update the component.

    return comp_config