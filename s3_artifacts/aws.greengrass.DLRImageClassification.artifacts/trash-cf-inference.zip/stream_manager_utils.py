"""
Author: Yap Jheng Khin
Sample code: AWS Official Documentation
"""
# Import third-party libraries
import asyncio
import os
from stream_manager import StreamManagerClient as _StreamManagerClient
from stream_manager import (
    ExportDefinition,
    MessageStreamDefinition,
    Persistence,
    ReadMessagesOptions,
    ResourceNotFoundException,
    S3ExportTaskDefinition,
    S3ExportTaskExecutorConfig,
    Status,
    StatusConfig,
    StatusLevel,
    StatusMessage,
    StrategyOnFull,
    StreamManagerException
)
from stream_manager.exceptions import NotEnoughMessagesException
from stream_manager.util import Util as aws_stream_manager_util

# Import modules
import config_utils

class StreamManagerClient:

    def __init__(self):
        try:
            # Use the client.
            # Extend the connection timeout to 1 minute since the default value (3 seconds) is not enough
            self.stream_manager_client = _StreamManagerClient(connect_timeout=60)
        # Log the errors
        except StreamManagerException as e:
            config_utils.logger.error(f"Error occurred when creating the stream manager client: {e}")
        except asyncio.TimeoutError as e:
            config_utils.logger.error(f"Request times out when creating the stream manager client: {e}")
        except ConnectionError as e:
            config_utils.logger.error(f"Unable to connect to the StreamManager server when creating the stream manager client: {e}")
        except Exception as e:
            config_utils.logger.error(f"General issue occurred when creating stream manager client: {e}")
        self.export_definition_id = 1

    def create_streams_with_stream_status(self, stream_names, stream_type="s3", stream_status_names=None):
        # Generate names for stream statuses if not given
        if stream_status_names == None:
            stream_status_names = [stream_name+"Status" for stream_name in stream_names]

        # Before creating the messsage stream, try deleting the existing stream and its status stream (if it exists) 
        # so that we have a fresh start. Please delete this if used in real production environment
        for stream_name in stream_names+stream_status_names:
            try:
                self.stream_manager_client.delete_message_stream(stream_name=stream_name)
            except ConnectionError:
                config_utils.logger.error(f"Unable to connect to the StreamManager server when trying to delete the existing {stream_name}: {e}")
            except asyncio.TimeoutError:
                config_utils.logger.error(f"Request times out when trying to delete the existing {stream_name}: {e}")
            except ResourceNotFoundException:
                pass

        try:
            stream_name = None
            stream_status_name = None

            for i in range(len(stream_names)):
                stream_name = stream_names[i]
                stream_status_name = stream_status_names[i]
                # Create the status stream to check the stream statuses
                self.stream_manager_client.create_message_stream(
                    MessageStreamDefinition(
                        name=stream_status_name, 
                        strategy_on_full=StrategyOnFull.RejectNewData,  # Reject any message request when the stream is full
                        persistence=Persistence.File,    # Write messages to the disk for long-term storage.
                    )
                )
                # Create the export definition
                export_definition = ExportDefinition() # Choose where/how the stream is exported to the AWS Cloud.)
                if stream_type == "s3":
                    s3_task_executor = S3ExportTaskExecutorConfig(
                        identifier="S3TaskExecutor" + stream_name + str(self.export_definition_id),  # Required
                        size_threshold_for_multipart_upload_bytes=config_utils.BYTES["5MiB"], # Apply multipart upload strategy if uploads are more than 5MiB
                        disabled=False, # Enable the export
                        status_config=StatusConfig( # Add an export status stream to add statuses for all S3 upload tasks.
                            status_level=StatusLevel.INFO,  # Default is INFO level statuses.
                            # Status Stream should be created before specifying in S3 Export Config.
                            status_stream_name=stream_status_name,
                        ),
                    )
                    export_definition.s3_task_executor = [s3_task_executor]

                # Create the export stream with the current export definition
                self.stream_manager_client.create_message_stream(
                    MessageStreamDefinition(
                        name=stream_name,
                        max_size=config_utils.BYTES["256MiB"],    # Default is 256 MB.
                        stream_segment_size=config_utils.BYTES["16MiB"],    # Default is 16 MB.
                        time_to_live_millis=None,    # By default, no TTL is enabled.
                        strategy_on_full=StrategyOnFull.RejectNewData,  # Reject any message request when the stream is full
                        persistence=Persistence.File,    # Write messages to the disk for long-term storage.
                        flush_on_write=False,    # Default is false.
                        export_definition=export_definition
                    )
                )
            config_utils.logger.info("Successfully created the streams used in inference component")
        # Log the errors
        except StreamManagerException as e:
            config_utils.logger.error(f"Exception occurred in StreamManager when creating {stream_name}: {e}")
        except asyncio.TimeoutError as e:
            config_utils.logger.error(f"Request times out when creating {stream_name}: {e}")
        except ConnectionError as e:
            config_utils.logger.error(f"Unable to connect to the StreamManager server when creating {stream_name}: {e}")
        except Exception as e:
            config_utils.logger.error(f"General issue occurred when creating {stream_name}: {e}")

        self.export_definition_id += 1

    def append_message(self, stream_name, message):
        sequence_number = self.stream_manager_client.append_message(
            stream_name, 
            message
        )
        config_utils.logger.info(f"Successfully appended {message} to {stream_name} with seq no {sequence_number}")
        return sequence_number

    def upload_data_to_s3(self, stream_name, local_file_path, s3_file_path):
        s3_export_task_definition = S3ExportTaskDefinition(
            input_url='file:'+os.path.abspath(local_file_path), 
            bucket=config_utils.comp_config.image_and_model_output_bucket_name, 
            key=s3_file_path
        )
        sequence_number = self.stream_manager_client.append_message(
            stream_name, 
            aws_stream_manager_util.validate_and_serialize_to_json_bytes(s3_export_task_definition)
        )
        return sequence_number

    def check_stream_status(self, status_stream_name, seq_number):
        try:
            next_seq = seq_number
            cur_stream_status = None
            messages_list = self.stream_manager_client.read_messages(
                status_stream_name,
                ReadMessagesOptions(
                    desired_start_sequence_number=seq_number, 
                    min_message_count=1, 
                    read_timeout_millis=1000
                ),
            )
            for message in messages_list:
                # Deserialize the status message first.
                status_message = aws_stream_manager_util.deserialize_json_bytes_to_obj(message.payload, StatusMessage)
                status_context = status_message.status_context
                cur_seq_number = status_context._get_sequence_number()
                stream_name = status_context._get_stream_name

                # Check the status of the status message. If the status is "Success",
                # the file was successfully uploaded to S3.
                # If the status was either "Failure" or "Cancelled", the server was unable to upload the file to S3.
                # We will print the message for why the upload to S3 failed from the status message.
                # If the status was "InProgress", the status indicates that the server has started uploading
                # the S3 task.
                if status_message.status == Status.Success:
                    config_utils.logger.info(f"Successfully uploaded the data (seq no: {cur_seq_number}) in the {stream_name} to S3")
                elif status_message.status == Status.InProgress:
                    config_utils.logger.info(f"The upload of data (seq no: {cur_seq_number}) in {stream_name} is in progress")
                    next_seq = message.sequence_number + 1
                elif status_message.status == Status.Failure:
                    config_utils.logger.error(
                        f"Failed to upload the data (sequence number: {cur_seq_number}) in the {stream_name} to S3: "+
                        status_message.message
                    )
                elif status_message.status == Status.Canceled:
                    config_utils.logger.error(
                        f"Cancelled upload the data (sequence number: {cur_seq_number}) in the {stream_name} to S3: "+
                        status_message.message
                    )
                cur_stream_status = status_message.status

        except NotEnoughMessagesException as e:
            # Skip this exception since it is not an error
            # Reference: https://forums.aws.amazon.com/thread.jspa?messageID=969089
            config_utils.logger.debug('No enough message to return before time out.')
        except Exception as e:
            config_utils.logger.error(f"Exception while checking {status_stream_name}: {e}")

        return cur_stream_status, next_seq

