"""
Author: Yap Jheng Khin
Sample code: AWS Official Documentation
"""
# Import third-party libraries
from awsiot.greengrasscoreipc.client import (
    SubscribeToConfigurationUpdateStreamHandler,
    SubscribeToTopicStreamHandler
)
from awsiot.greengrasscoreipc.model import (
    ConfigurationUpdateEvents,
    SubscriptionResponseMessage
)
import json
import os
from PIL import Image
from shutil import copyfile

# Import modules
import config_utils
import prediction_utils

class ConfigUpdateHandler(SubscribeToConfigurationUpdateStreamHandler):
    """
    Custom handle of the subscribed configuration events(steam, error and close).
    Due to the SDK limitation, another request from within this callback cannot to be sent.
    Here, it just logs the event details, updates the updated_config to true.
    """
    def on_stream_event(event: ConfigurationUpdateEvents) -> None:
        config_utils.logger.info(event.configuration_update_event)
        config_utils.UPDATED_CONFIG = True

    def on_stream_error(error: Exception) -> bool:
        config_utils.logger.error("Error in config update subscriber - {0}".format(error))
        return False

    def on_stream_closed() -> None:
        config_utils.logger.info("Config update subscription stream was closed")

# -------------------------------------------------------------------------------------------------- #
# Inference component works with the publish/subscribe IPC service to subscribe to a topic.
# Client devices publish images to this topic. The component receives the images from this topic.
# The component predicts the images before publishing the result back to the client devices.
# -------------------------------------------------------------------------------------------------- #
class InferenceRequestSubscriptionHandler(SubscribeToTopicStreamHandler):
    """
    Author: Yap Jheng Khin
    Event handler for SubscribeToTopicOperation.
    Handle messages received from a subscribed topic.

    Custom handle of the subscribed configuration events(steam, error and close).
    Due to the SDK limitation, another request from within this callback cannot to be sent.
    Here, it just add the request to a queue and the functions outside will handle the request.
    """
    def on_stream_event(event: SubscriptionResponseMessage) -> None:
        # IPC client calls this when a MQTT message is received
        try:
            config_utils.logger.info(f"The message received: {event}")
            config_utils.inference_requests_queue.append(event)
        except Exception as e:
            config_utils.logger.error(f"Error occurred while receiving message: {e}")

    def on_stream_error(error: Exception) -> bool:
        config_utils.logger.error(f"Error occurred when : {error}")
        return False  # Return True to close stream, False to keep stream open.

    def on_stream_closed() -> None:
        config_utils.logger.info(f"The subscription of the topic stream is closed")

# -------------------------------------------------------------------------------------------------- #
# The function that handles the inference request. This function will get called from the main.py
# if there is any request in the queue.
# -------------------------------------------------------------------------------------------------- #
def process_inference_request(ipc_client, event: SubscriptionResponseMessage):
    try:
        # ------------------------------------------------ #
        # Validate the inference request
        # ------------------------------------------------ #
        inference_request, inference_response = validate_inference_request(event)

        if inference_response["res"]["code"] == -1:
            # Since the response topic is not available, the component doesn't know where to send command reply to
            # Ignore this request
            return
        
        response_topic = inference_request["res-topic"]

        if inference_response["res"]["code"] == 400: # Bad request
            # If the payload is problematic but response topic is available, then
            # send back to the sender to inform the error status and description
            config_utils.logger.warn(f"Failed to process the inference request due to wrong payload's format")
            ipc_client.publish_json_to_topic(response_topic, inference_response)
            return

        # ------------------------------------------------ #
        # Retrieve the image
        # ------------------------------------------------ #
        # According to the documentation in https://docs.aws.amazon.com/general/latest/gr/iot-core.html,
        # The maximum payload for every publish request must be smaller than 128 KB.
        # So, the component assumes that the IoT device uses other protocols like HTTP to send image,
        # and the image is named as "<client-id>-<utc-timestamp>.<img-extension>" before storing in IMG_DIR.

        # Form the new image path
        image_filename = f'{inference_request["session-id"]}.{inference_request["action"]["img-format"]}'
        image_path = os.path.join(config_utils.comp_config.device_img_dir, image_filename)
        
        # Since no IoT hardware is available, fetch the sample image from another directory instead
        sample_image_filename = config_utils.comp_config.sample_images[config_utils.comp_config.image_idx]
        sample_image_path = os.path.join(config_utils.comp_config.sample_device_img_dir, sample_image_filename)
        # Copy the image
        copyfile(sample_image_path, image_path)
        # Increment image_idx by 1 to use the next image
        config_utils.comp_config.image_idx += 1
        # Fetch the copied image
        image = Image.open(image_path)
        config_utils.logger.info(f"Successfully retrieve image from {image_path}")

        # ------------------------------------------------ #
        # Perform the model inference
        # ------------------------------------------------ #
        config_utils.logger.info(f"Starting to perform inference")
        pred_trash_type, inference_log = prediction_utils.classify_trash(inference_request, image)

        # ------------------------------------------------------------------------ #
        # Append the model output/inference log to a file
        # The stream manager later sends the logs in batches as scheduled by the OS
        # ------------------------------------------------------------------------- #
        model_output_file_path = os.path.join(
                config_utils.comp_config.model_output_dir, 
                config_utils.comp_config.model_output_filename
        )
        with open(model_output_file_path, 'a') as f:
            f.write(json.dumps(inference_log)+'\n')

        # ------------------------------------------------ #
        # Send the model prediction to the client device
        # ------------------------------------------------ #
        inference_response["res"]["prediction"] = pred_trash_type
        # Fetch the destination topic that the client device is subscribing to 
        ipc_client.publish_json_to_topic(response_topic, inference_response)

    except Exception as e:
        config_utils.logger.error(f"Error occurred when handling an inference request: {e}")

def validate_inference_request(event: SubscriptionResponseMessage):
    """
    Validate the format before processing the inference request.
    """
    response = {
        "sequence": None,
        "client-id": None,
        "session-id": None,
        "res": {
            "code": None, # Indicate the request is successful
            "desc": []
        },
    }

    # Fetch and validate the request payload from the SubscriptionResponseMessage
    # before returning it to the caller
    request = None

    try:
        if event.json_message == None and event.binary_message == None:
            response["res"]["desc"].append("The request doesn't have a body.")
            response["res"]["code"] = -1 # Flag to ignore the request
            config_utils.logger.warn(f"Failed to process the inference request since the request body is missing: {request}")
            return request, response

        if event.json_message != None:
            request = event.json_message.message

        else: # event.binary_message != None

            # Assume that the encoding of the binary message is utf-8
            try:
                request = json.loads(event.binary_message.message.decode('utf-8'))
            except Exception as e:
                response["res"]["desc"].append("The request must be in JSON and UTF-8 encoded.")
                response["res"]["code"] = -1 # Flag to ignore the request
                config_utils.logger.warn(f"Failed to process the inference request since payload cannot be interpreted: {request}")
                return request, response

        if 'res-topic' not in request:
            response["res"]["code"] = -1 # Flag to ignore the request
            config_utils.logger.warn(f"Failed to process the inference request since response topic is not available: {request}")
            return request, response

        attributes = ["client-id", "session-id", "utc-timestamp", "sequence"]
        for attribute in attributes:
            if attribute not in request:
                response["res"]["desc"].append(f"The request does not have attribute named '{attribute}'.")
            else:
                response[attribute] = request[attribute]

        action = "action"
        type = "type"
        image_attributes = ["img-format"]
        if action in request:
            if type in request[action]:
                # Update the validation logic in the future if other command/action type is added
                if request[action][type] == "trash-classification":
                    for image_attribute in image_attributes:
                        if image_attribute not in request[action]:
                            response["res"]["desc"].append(f"Failed to retrieve uploaded image file since {image_attribute} is not set.")
                else:
                    response["res"]["desc"].append("The requested action type is not supported.")
            else:
                response["res"]["desc"].append("The value of action type is not set.")
        else:
            response["res"]["desc"].append("The request does not have attribute named 'action'.")

        # Set the response status
        if len(response["res"]["desc"]) > 0:
            response["res"]["code"] = 400 # Bad request
        else:
            response["res"]["code"] = 200 # OK

        config_utils.logger.info(f"Successfully validated the inference request and form the response's skeleton: {response}")
    except Exception as e:
        config_utils.logger.error(f"Error occurred when validating an inference request: {e}")

    return request, response