"""
Author: Yap Jheng Khin
Sample code: AWS Official Documentation
"""
# Import third-party libraries
from datetime import datetime
import os
from shutil import make_archive
from time import sleep
from stream_manager import Status as StreamStatus

# Import local files/modules
import config_utils
import ipc_utils
import stream_handlers
import stream_manager_utils

# ------------------------------------------------------------------------------------------------ #
# 1) Initiate connections to essential services and components
# ------------------------------------------------------------------------------------------------ #
# Attempting to connect to IPC service
ipc_client = ipc_utils.IPCClient(connection_timeout=30)

# Attempting to connect to stream manager
stream_manager_client = stream_manager_utils.StreamManagerClient()

# ------------------------------------------------------------------------------------------------ #
# 2) Retrieve configuration from the recipe and make relevant changes to the component accordingly
# ------------------------------------------------------------------------------------------------ #
# Get initial configuration from the recipe
config_utils.comp_config = config_utils.set_configuration(ipc_client.get_configuration())

# Subscribe to the subsequent configuration changes
ipc_client.get_config_updates()

# ------------------------------------------------------------------------------------------------ #
# 3) Set up streams to export data in batches
# ------------------------------------------------------------------------------------------------ #
# Create a message stream to export trash images to S3 bucket
image_stream_name = "TrashImageStream"
# Create a message stream to export model outputs in batches to S3 bucket
model_output_stream_name = "ModelOuputStream"
stream_names = [image_stream_name, model_output_stream_name]
# Create the export streams through the stream manager client
stream_manager_client.create_streams_with_stream_status(stream_names, stream_type="s3")

# ------------------------------------------------------------------------------------------------ #
# 4) Set up topic subscription to receive inference requests from the client devices
# ------------------------------------------------------------------------------------------------ #
# Provide a subscription handler that handles event messages, errors, and stream closure. 
topic_to_subscribe = config_utils.comp_config.topic_to_subscribe
subscription_handler = stream_handlers.InferenceRequestSubscriptionHandler
ipc_client.subscribe_topic(topic_to_subscribe, subscription_handler)

try:
    message_statuses = {}

    while True:
        # ------------------------------------------------------------------------------------------------ #
        # 1) Checking for configuration updates
        # ------------------------------------------------------------------------------------------------ #
        # Keeps checking for the updated_config value every one second. If the config changes, it's `True` and
        # inference will be run with the updated config (run_inference) after setting the new config(set_configuration).
        # Toggle it back to `False` and look out for the config updates.
        if config_utils.UPDATED_CONFIG:
            # Assign the updated configuration to `inference_comp_config` if component is robust towards any configuration update
            # Refer to the source code in `set configuration` for more explanation
            _ = config_utils.set_configuration(ipc_client.get_configuration())
            config_utils.UPDATED_CONFIG = False

        # ------------------------------------------------------------------------------------------------ #
        # 2) Checking for any queued inference requests
        # ------------------------------------------------------------------------------------------------ #
        # In this assignment, simple array is used to queue the response, which is not practical in production
        # environment.
        if config_utils.inference_requests_queue:
            inference_request_event = config_utils.inference_requests_queue.popleft()
            # Process the request one by one
            config_utils.logger.info(f"Starting to process {inference_request_event}")
            stream_handlers.process_inference_request(ipc_client, inference_request_event)

        # ------------------------------------------------------------------------------------------------ #
        # 3) Export streams to the S3 bucket
        # 
        # Stream manager handles data differently depending on the export destinations. Specifically,
        # for uploading images to the S3 bucket:
        #
        # 1) In production environment:
        # i) For uploading images, an automatic scheduler should be implemented to zip the images to 
        # reduce communication cost. For example, the scheduler can zip the images on regular basis or
        # if the size of the image directory exceeds a threshold. Then, append the zipped file into the 
        # stream. The stream manager will apply multipart upload strategy by sending the file part by part 
        # instead as a whole, which requires lesser network bandwidth and provides more flexible upload 
        # options. 
        # ii) The same thing goes for uploading model outputs, save the models outputs into a file and 
        # program a scheduler to send the file to the S3 bucket.
        # 
        # 2) In this assignment, no automatic smart scheduler is implemented. Instead, zip the images as 
        # soon as all sample images have been used for inference. Conveniently, no inference request will 
        # be sent if all samples images have been used.
        # ------------------------------------------------------------------------------------------------ #

        # In this assignment,
        # Check if all samples images have been used, if yes, upload the images to the S3 bucket
        # Each file name is appended with local date time to uniquely identify each exported file 
        if config_utils.comp_config.image_idx >= len(config_utils.comp_config.sample_images):
            config_utils.logger.info(f"Starting to upload images and model outputs to {config_utils.comp_config.image_and_model_output_bucket_name}")

            # Upload the model outputs
            model_output_file_path = os.path.join(
                config_utils.comp_config.model_output_dir, 
                config_utils.comp_config.model_output_filename
            )
            model_output_s3_filename = f"model-outputs-{str(datetime.today().strftime('%Y-%m-%dT%H:%M:%S'))}.txt"
            model_output_message_seq_no = stream_manager_client.upload_data_to_s3(
                model_output_stream_name, 
                local_file_path = model_output_file_path, 
                s3_file_path = f"model_outputs/{model_output_s3_filename}"
            )
            # Upload the images
            img_dir = config_utils.comp_config.device_img_dir
            output_zip_filename = f"images-{str(datetime.today().strftime('%Y-%m-%dT%H:%M:%S'))}"
            zip_file_path = make_archive(output_zip_filename, 'zip', img_dir)
            image_message_seq_no = stream_manager_client.upload_data_to_s3(
                image_stream_name, 
                local_file_path = zip_file_path, 
                s3_file_path = f"images/{output_zip_filename}.zip"
            )

            message_statuses = {
                f"{image_stream_name}Status": image_message_seq_no,
                f"{model_output_stream_name}Status": model_output_message_seq_no
            }

            # Reset the image index to 0
            config_utils.comp_config.image_idx = 0

        # ------------------------------------------------------------------------------------------------ #
        # 4) Periodically check the upload status of the streams
        # Continue checking the status until the uploading has either succeeded, cancelled, or failed
        # ------------------------------------------------------------------------------------------------ #
        if len(message_statuses) > 0:
            new_message_statuses = {}

            for status_stream_name, seq_number in message_statuses.items():
                # Read status from the status stream and log the status
                cur_stream_status, next_seq_number = stream_manager_client.check_stream_status(
                    status_stream_name, 
                    seq_number
                )

                # If the status stream don't have new messages or the current stream status is in progress
                if cur_stream_status == None or cur_stream_status == StreamStatus.InProgress:
                    # Add back the record to check the status again since the file is uploading
                    # Check the stream status again in the next loop
                    new_message_statuses[status_stream_name] = next_seq_number
                
                elif cur_stream_status == StreamStatus.Success:
                    # If the export of device images is successful
                    if status_stream_name == f"{image_stream_name}Status":
                        # Delete the device images after a successful upload to save space
                        img_dir = config_utils.comp_config.device_img_dir
                        for file in os.listdir(img_dir):
                            if not file.endswith('.zip'): # Delete image file only
                                os.remove(os.path.join(img_dir, file))
                    # Else if the export of model outputs is successful
                    elif status_stream_name == f"{model_output_stream_name}Status":
                        # Delete the model outputs after a successful upload to save space
                        model_output_file_path = os.path.join(
                            config_utils.comp_config.model_output_dir, 
                            config_utils.comp_config.model_output_filename
                        )
                        os.remove(model_output_file_path)

                elif cur_stream_status == StreamStatus.Failure or cur_stream_status == StreamStatus.Canceled:
                    # In this assignment, the device images and model outputs will remain in the component's
                    # working directory and will re-upload in the next cycle [details at section 3].
                    # In the industry, custom code should be implemented here to try to re-upload the files again. 
                    pass

            message_statuses = new_message_statuses
        
        sleep(1)
except InterruptedError as e:
    config_utils.logger.warn(f"danish.GCS.TrashClassification has stopped: {e}")
except Exception as e:
    config_utils.logger.error(f"Error when running danish.GCS.TrashClassification process: {e}")