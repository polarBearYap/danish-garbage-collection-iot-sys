#For x86_64, download and install miniconda and create a miniconda environment from a provided `environment.yaml`
#argument with all necessary dependencies required by DLR
#This environment will be activated immediately after creation so that when DLR is installed afterwards, it will only
#exist inside this environment
install_conda_x86_64() {
    #Check if we have already installed and set up conda on this device; if so, skip the installation
    if [ -f "${ml_root_path}/greengrass_ml_dlr_conda/bin/conda" ]; then
        return 0
    fi

    # Remove if partially created env exists
    rm -rf "${ml_root_path}/greengrass_ml_dlr_conda"

    environment_file="${1}"
    mkdir -p ${ml_root_path}
    wget "https://repo.anaconda.com/miniconda/Miniconda3-latest-Linux-x86_64.sh" -O "${ml_root_path}/miniconda.sh"
    bash "${ml_root_path}/miniconda.sh" -b -p "${ml_root_path}/greengrass_ml_dlr_conda"
    rm "${ml_root_path}/miniconda.sh"

    export PATH="${ml_root_path}/greengrass_ml_dlr_conda/bin:$PATH"
    #See https://github.com/conda/conda/issues/7980 for an explanation of the below line
    eval "$(${ml_root_path}/greengrass_ml_dlr_conda/bin/conda shell.bash hook)"
    conda env create -f $environment_file
    conda activate greengrass_ml_dlr_conda

    #Uncomment to make `awscam` accessible inside conda for AWS Deeplens (use with caution)
    #sudo ln -s /usr/lib/python3/dist-packages/awscam "${ml_root_path}/greengrass_ml_dlr_conda/envs/greengrass_ml_dlr_conda/lib/python3.7/site-packages/"
    #sudo ln -s /usr/lib/python3/dist-packages/awscamdldt.so "${ml_root_path}/greengrass_ml_dlr_conda/envs/greengrass_ml_dlr_conda/lib/python3.7/site-packages/"
}

##Setup a venv for all python library installations on platforms with limited conda support
setup_venv() {
    machine="${1}"
    if [ ! -f "${ml_root_path}/greengrass_ml_dlr_venv/bin/activate" ]; then
        # Remove if partially created env exists
        rm -rf "${ml_root_path}/greengrass_ml_dlr_venv"

        #If the venv does not exist already, create it

        # Installation of python packages(eg.numpy) on devices is super slow as it requires
        # compiling. To make use of the libraries that already present on the device(eg. Certain
        # version of numpy is shipped with the jetpack sdk), we create the virtual env with access
        # to the modules that are present system wide.
        python3 -m venv ${ml_root_path}/greengrass_ml_dlr_venv --system-site-packages

    fi

    source ${ml_root_path}/greengrass_ml_dlr_venv/bin/activate
    cd ${ml_root_path}/greengrass_ml_dlr_venv

    #Uncomment to make `picamera` accessible inside venv for Raspberry pi (use with caution)
    #sudo ln -s /usr/lib/python3/dist-packages/picamera "${ml_root_path}/greengrass_ml_dlr_venv/lib/python3.7/site-packages"
}

install_conda_darwin() {
    #Check if we have already installed and set up conda on this device; if so, skip the installation
    if [ -f "${ml_root_path}/greengrass_ml_dlr_conda/bin/conda" ]; then
        return 0
    fi

    # Remove if partially created env exists
    rm -rf "${ml_root_path}/greengrass_ml_dlr_conda"

    environment_file="${1}"
    mkdir -p ${ml_root_path}
    wget "https://repo.anaconda.com/miniconda/Miniconda3-latest-MacOSX-x86_64.sh" -O "${ml_root_path}/miniconda.sh"
    bash "${ml_root_path}/miniconda.sh" -b -p "${ml_root_path}/greengrass_ml_dlr_conda"
    rm "${ml_root_path}/miniconda.sh"

    export PATH="${ml_root_path}/greengrass_ml_dlr_conda/bin:$PATH"
    #See https://github.com/conda/conda/issues/7980 for an explanation of the below line
    eval "$(${ml_root_path}/greengrass_ml_dlr_conda/bin/conda shell.bash hook)"
    conda env create -f $environment_file
    conda activate greengrass_ml_dlr_conda
}
