"""
Author: Yap Jheng Khin
Sample code: AWS Official Documentation
"""
# Import third-party libraries
from awsiot.greengrasscoreipc.model import QOS
from collections import deque
from dataclasses import dataclass
import json
from logging import (
    INFO, 
    StreamHandler, 
    getLogger
)
import os
from sys import stdout
# --------------------------------------------------------------- #
# Get a logger
# --------------------------------------------------------------- #
logger = getLogger()
handler = StreamHandler(stdout)
logger.setLevel(INFO)
logger.addHandler(handler)

# --------------------------------------------------------------- #
# Struct that stores component configurations for other files/ 
# modules to access
# --------------------------------------------------------------- #
@dataclass
class TelemetryComponentConfig:
    # --------------------------------------------------------------- #
    # Configurable
    # --------------------------------------------------------------- #
    # Get the paths from the env variables.
    iot_analytics_channel = "danish_gcs_bin_telemetry_iot_analytics_channel"
    qos_type = QOS.AT_LEAST_ONCE
    telemetry_local_dir = os.path.expandvars(os.environ.get("TELEMETRY_PATH"))
    timeout=30 # the default timeout to activate mqtt topic subscription is 30 seconds
    topics_to_subscribe = None # the topics that the component subscribes to receive client device telemetry
    # --------------------------------------------------------------- #
    # Non-configurable
    # --------------------------------------------------------------- #
    # max_batch_size: The maximum size of a batch to send to IoT Analytics. 
    # Fill level telemetry will be queued until the `max_batch_size` is reached, after which they will then be uploaded.
    batch_count = 0
    # In this assignment, 15 client devices send 5 randomly-generated telemetry, respectively
    # So, the stream will be exported three times
    max_batch_size = 25
    telemetry_filename = "telemetry.txt"
    status_stream_seq_no = 0

# --------------------------------------------------------------- #
# Constants that are shared between files and modules
# --------------------------------------------------------------- #
UPDATED_CONFIG = False
comp_config = TelemetryComponentConfig()
received_telemetry_queue = deque()

# --------------------------------------------------------------- #
# Unit conversion constants
# --------------------------------------------------------------- #
BYTES = {
    "5MiB": 5242880,
    "16MiB": 16777216,
    "256MiB": 268435456
}
MILLISECONDS = {
    "24hr": 9223372036854 
}

# --------------------------------------------------------------- #
# Variables that are configurable from the component's recipe
# The default values can be overwritten by component's recipe
# --------------------------------------------------------------- #

def set_configuration(config):
    """
    Author: Amazon

    Sets a new config object with the combination of updated and default configuration as applicable.
    """
    comp_config = TelemetryComponentConfig()

    topics_to_subscribe = config["accessControl"]["aws.greengrass.ipc.pubsub"]
    topics_to_subscribe = topics_to_subscribe["danish.GCS.TelemetryIngestion:pubsub:1"]["resources"]

    logger.info(f'The passed-in topics_to_sub is {topics_to_subscribe}')

    comp_config.topics_to_subscribe = topics_to_subscribe

    if "ConnectionTimeout" in config:
        comp_config.timeout = config["ConnectionTimeout"]

    if "QOS" in config:
        comp_config.qos_type = config["QOS"]

    if "UploadTelemetryOnIoTAnalyticsChannel" in config:
        comp_config.iot_analytics_channel = config["UploadTelemetryOnIoTAnalyticsChannel"]

    # ------------------------------------------------------------------------------------------------ #
    # Create directories to store images and model outputs, respectively
    # ------------------------------------------------------------------------------------------------ #

    # Create the directory to store device telemetry if not exists
    if not os.path.exists(comp_config.telemetry_local_dir):
        os.makedirs(comp_config.telemetry_local_dir)

    # **IMPORTANT**
    # In production environment, the component should make relevant changes based on the updated configuration.
    # Now, the component will not be updated upon subsequent configuration updates.
    # If configuration changes have been applied, please uninstall and redeploy the component again.
    # Refer to artifacts from public components aws.greengrass.DLRImageClassification to learn on how to update the component.

    return comp_config