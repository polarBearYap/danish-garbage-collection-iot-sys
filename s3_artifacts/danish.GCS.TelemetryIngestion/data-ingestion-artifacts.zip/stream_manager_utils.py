"""
Author: Yap Jheng Khin
Sample code: AWS Official Documentation
"""
# Import third-party libraries
import asyncio
from stream_manager import StreamManagerClient as _StreamManagerClient
from stream_manager import (
    ExportDefinition,
    IoTAnalyticsConfig,
    MessageStreamDefinition,
    Persistence,
    ResourceNotFoundException,
    S3ExportTaskExecutorConfig,
    StatusConfig,
    StatusLevel,
    StrategyOnFull,
    StreamManagerException
)

# Import modules
import config_utils

class StreamManagerClient:

    def __init__(self):
        try:
            # Use the client.
            # Extend the connection timeout to 1 minute since the default value (3 seconds) is not enough
            self.stream_manager_client = _StreamManagerClient(connect_timeout=60)
        # Log the errors
        except StreamManagerException as e:
            config_utils.logger.error(f"Error occurred when creating the stream manager client: {e}")
        except asyncio.TimeoutError as e:
            config_utils.logger.error(f"Request times out when creating the stream manager client: {e}")
        except ConnectionError as e:
            config_utils.logger.error(f"Unable to connect to the StreamManager server when creating the stream manager client: {e}")
        except Exception as e:
            config_utils.logger.error(f"General issue occurred when creating stream manager client: {e}")
        self.export_definition_id = 1

    def create_streams_with_stream_status(self, stream_names, stream_type="s3", stream_status_names=None):
        # Generate names for stream statuses if not given
        if stream_status_names == None:
            stream_status_names = [stream_name+"Status" for stream_name in stream_names]

        # Before creating the messsage stream, try deleting the existing stream and its status stream (if it exists) 
        # so that we have a fresh start. Please delete this if used in real production environment
        for stream_name in stream_names+stream_status_names:
            try:
                self.stream_manager_client.delete_message_stream(stream_name=stream_name)
            except ConnectionError:
                config_utils.logger.error(f"Unable to connect to the StreamManager server when trying to delete the existing {stream_name}: {e}")
            except asyncio.TimeoutError:
                config_utils.logger.error(f"Request times out when trying to delete the existing {stream_name}: {e}")
            except ResourceNotFoundException:
                pass

        try:
            stream_name = None
            stream_status_name = None

            for i in range(len(stream_names)):
                stream_name = stream_names[i]
                stream_status_name = stream_status_names[i]
                # Create the status stream to check the stream statuses
                self.stream_manager_client.create_message_stream(
                    MessageStreamDefinition(
                        name=stream_status_name, 
                        strategy_on_full=StrategyOnFull.RejectNewData,  # Reject any new message when the stream is full
                        persistence=Persistence.File,    # Write messages to the disk for long-term storage.
                    )
                )
                # Create the export definition
                export_definition = ExportDefinition() # Choose where/how the stream is exported to the AWS Cloud.)
                if stream_type == "s3":
                    s3_task_executor = S3ExportTaskExecutorConfig(
                        identifier="S3TaskExecutor" + stream_name + str(self.export_definition_id),  # Required
                        size_threshold_for_multipart_upload_bytes=config_utils.BYTES["5MiB"], # Apply multipart upload strategy if uploads are more than 5MiB
                        disabled=False, # Enable the export
                        status_config=StatusConfig( # Add an export status stream to add statuses for all S3 upload tasks.
                            status_level=StatusLevel.INFO,  # Default is INFO level statuses.
                            # Status Stream should be created before specifying in S3 Export Config.
                            status_stream_name=stream_status_name,
                        ),
                    )
                    export_definition.s3_task_executor = [s3_task_executor]

                elif stream_type == "iot_analytics":
                    # Add `batch_size` and `batch_interval_millis` to the component's configuration if want to 
                    # customize this parameter in the future development
                    iot_analytics_config = IoTAnalyticsConfig(
                        identifier="IoTAnalyticsTaskExecutor" + stream_name + str(self.export_definition_id),  # Required
                        iot_channel=config_utils.comp_config.iot_analytics_channel,
                        iot_msg_id_prefix="danish-gsc-tele-ch",
                        batch_size=config_utils.comp_config.max_batch_size, 
                        start_sequence_number=0,
                        disabled=False # Enable the export
                    )
                    export_definition.iot_analytics = [iot_analytics_config]

                # Create the export stream with the current export definition
                self.stream_manager_client.create_message_stream(
                    MessageStreamDefinition(
                        name=stream_name,
                        max_size=config_utils.BYTES["256MiB"],    # Default is 256 MB.
                        stream_segment_size=config_utils.BYTES["16MiB"],    # Default is 16 MB.
                        time_to_live_millis=None,    # By default, no TTL is enabled.
                        strategy_on_full=StrategyOnFull.RejectNewData,  # Reject any new message when the stream is full
                        persistence=Persistence.File,    # Write messages to the disk for long-term storage.
                        flush_on_write=False,    # Default is false.
                        export_definition=export_definition
                    )
                )
            config_utils.logger.info("Successfully created the streams used in data ingestion component")
        # Log the errors
        except StreamManagerException as e:
            config_utils.logger.error(f"Exception occurred in StreamManager when creating {stream_name}: {e}")
        except asyncio.TimeoutError as e:
            config_utils.logger.error(f"Request times out when creating {stream_name}: {e}")
        except ConnectionError as e:
            config_utils.logger.error(f"Unable to connect to the StreamManager server when creating {stream_name}: {e}")
        except Exception as e:
            config_utils.logger.error(f"General issue occurred when creating {stream_name}: {e}")

        self.export_definition_id += 1

    def append_message(self, stream_name, message):
        sequence_number = self.stream_manager_client.append_message(
            stream_name, 
            message
        )
        config_utils.logger.info(f"Successfully appended {message} to {stream_name} with seq no {sequence_number}")
        return sequence_number