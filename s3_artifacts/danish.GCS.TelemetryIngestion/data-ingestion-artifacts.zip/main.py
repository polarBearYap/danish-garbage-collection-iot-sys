"""
Author: Yap Jheng Khin
Sample code: AWS Official Documentation
"""
# Import third-party libraries
from time import sleep

# Import local files/modules
import config_utils
import ipc_utils
import stream_handlers
import stream_manager_utils

# ------------------------------------------------------------------------------------------------ #
# 1) Initiate connections to essential services and components
# ------------------------------------------------------------------------------------------------ #
# Attempting to connect to IPC service
ipc_client = ipc_utils.IPCClient(connection_timeout=30)

# Attempting to connect to stream manager
stream_manager_client = stream_manager_utils.StreamManagerClient()

# ------------------------------------------------------------------------------------------------ #
# 2) Retrieve configuration from the recipe and make relevant changes to the component accordingly
# ------------------------------------------------------------------------------------------------ #
# Get initial configuration from the recipe
config_utils.comp_config = config_utils.set_configuration(ipc_client.get_configuration())

# Subscribe to the subsequent configuration changes
ipc_client.get_config_updates()

# ------------------------------------------------------------------------------------------------ #
# 3) Set up streams to export data in batches
# ------------------------------------------------------------------------------------------------ #
# Create a message stream to export trash images to IoT Analytics channel
telemetry_stream_name = "FillLevelTelemetryStream"
stream_names = [telemetry_stream_name]
# Create the export streams through the stream manager client
stream_manager_client.create_streams_with_stream_status(stream_names, stream_type="iot_analytics")

# ------------------------------------------------------------------------------------------------ #
# 4) Set up topic subscription to receive fill level telemetry from the client devices
# ------------------------------------------------------------------------------------------------ #
# Provide a subscription handler that handles event messages, errors, and stream closure.
# Due to SDK limitation, need to subscribe the topic one by one instead of using topic filter
topics_to_subscribe = config_utils.comp_config.topics_to_subscribe
subscription_handler = stream_handlers.TelemetrySubscriptionHandler

for topic_to_subscribe in topics_to_subscribe:
    ipc_client.subscribe_topic(topic_to_subscribe, subscription_handler)

try:
    message_statuses = {}

    while True:
        # ------------------------------------------------------------------------------------------------ #
        # 1) Checking for configuration updates
        # ------------------------------------------------------------------------------------------------ #
        # Keeps checking for the updated_config value every one second. The ConfigUpdateHandler will set the 
        # `UPDATED_CONFIG` flag to true upon receiving any configuration update event.
        if config_utils.UPDATED_CONFIG:
            _ = config_utils.set_configuration(ipc_client.get_configuration())
            # Toggle it back to `False` and look out for the subsequent config updates.
            config_utils.UPDATED_CONFIG = False

        # ------------------------------------------------------------------------------------------------ #
        # 2) Checking for any queued client device telemetry
        # ------------------------------------------------------------------------------------------------ #
        # In this assignment, simple array is used to queue the response, which is not practical in production
        # environment.
        if config_utils.received_telemetry_queue:
            telemetry_event = config_utils.received_telemetry_queue.popleft()
            config_utils.logger.info(f"Starting to process {telemetry_event}")
            try:
                # ------------------------------------------------ #
                # Retrieve the device telemetry
                # ------------------------------------------------ #
                if telemetry_event.json_message == None and telemetry_event.binary_message == None:
                    config_utils.logger.warn(f"Failed to retrieve the telemetry since the body is missing: {telemetry_event}")
                else:
                    if telemetry_event.json_message != None:
                        telemetry = telemetry_event.json_message.message
                    else:
                        telemetry = telemetry_event.binary_message.message
                # ------------------------------------------------ #
                # Append the telemetry to the stream
                # ------------------------------------------------ #
                stream_manager_client.append_message(telemetry_stream_name, telemetry)
                # Update the batch size
                config_utils.comp_config.batch_count += 1

            except Exception as e:
                config_utils.logger.error(f"Error occurred when processing an received telemetry: {e}")

        # ------------------------------------------------------------------------------------------------ #
        # 3) Check the upload status of the streams if maximum batch size is reached
        # ------------------------------------------------------------------------------------------------ #
        # In this assignment, check if the current batch count reaches the maximum batch size. 
        # If yes, call stream manager client to check the stream's upload status using the corresponding status stream.
        if config_utils.comp_config.batch_count >= config_utils.comp_config.max_batch_size:
            config_utils.logger.info(f"Maximum batch count of {config_utils.comp_config.max_batch_size} has been reached, exporting to {telemetry_stream_name}.")

            message_statuses = {
                f"{telemetry_stream_name}Status": config_utils.comp_config.status_stream_seq_no,
            }

            # Reset the batch count to 0
            config_utils.comp_config.batch_count = 0
        
        sleep(1)
except InterruptedError as e:
    config_utils.logger.warn(f"danish.GCS.TelemetryIngestion has stopped: {e}")
except Exception as e:
    config_utils.logger.error(f"Error when running danish.GCS.TelemetryIngestion process: {e}")