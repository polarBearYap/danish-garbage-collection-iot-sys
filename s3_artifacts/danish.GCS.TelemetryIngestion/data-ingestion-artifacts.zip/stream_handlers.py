"""
Author: Yap Jheng Khin
Sample code: AWS Official Documentation
"""
# Import third-party libraries
from awsiot.greengrasscoreipc.client import (
    SubscribeToConfigurationUpdateStreamHandler,
    SubscribeToTopicStreamHandler
)
from awsiot.greengrasscoreipc.model import (
    ConfigurationUpdateEvents,
    SubscriptionResponseMessage
)

# Import modules
import config_utils

class ConfigUpdateHandler(SubscribeToConfigurationUpdateStreamHandler):
    """
    Custom handle of the subscribed configuration events(steam, error and close).
    Due to the SDK limitation, another request from within this callback cannot to be sent.
    Here, it just logs the event details, updates the updated_config to true.
    """
    def on_stream_event(event: ConfigurationUpdateEvents) -> None:
        config_utils.logger.info(event.configuration_update_event)
        config_utils.UPDATED_CONFIG = True

    def on_stream_error(error: Exception) -> bool:
        config_utils.logger.error("Error in config update subscriber - {0}".format(error))
        return False

    def on_stream_closed() -> None:
        config_utils.logger.info("Config update subscription stream was closed")

# -------------------------------------------------------------------------------------------------- #
# Data ingestion component works with the publish/subscribe IPC service to subscribe to a topic.
# Client devices publish images to this topic. The component receives the images from this topic.
# The component predicts the images before publishing the result back to the client devices.
# -------------------------------------------------------------------------------------------------- #
class TelemetrySubscriptionHandler(SubscribeToTopicStreamHandler):
    """
    Author: Yap Jheng Khin
    Event handler for SubscribeToTopicOperation.
    Handle messages received from a subscribed topic.

    Due to the SDK limitation, it cannot call stream manager client within the on_stream_event function 
    itself. Instead, the received telemetry event is queued and handled by the function outside the 
    handler.
    """
    def on_stream_event(event: SubscriptionResponseMessage) -> None:
        # IPC client calls this when a MQTT message is received
        try:
            config_utils.logger.info(f"The message received: {event}")
            config_utils.received_telemetry_queue.append(event)
        except Exception as e:
            config_utils.logger.error(f"Error occurred while receiving message: {e}")

    def on_stream_error(error: Exception) -> bool:
        config_utils.logger.error(f"Error occurred when : {error}")
        return False  # Return True to close stream, False to keep stream open.

    def on_stream_closed() -> None:
        config_utils.logger.info(f"The subscription of the topic stream is closed")